import { createContext, useContext, useState } from 'react';
import { Artwork, Bid, mockArtworks, mockBids } from '@/lib/constants';
import { useToast } from '@/hooks/use-toast';

interface BiddingContextType {
  artworks: Artwork[];
  bids: Bid[];
  placeBid: (artworkId: string, amount: number) => Promise<void>;
  getArtworkById: (id: string) => Artwork | undefined;
  getUserBids: () => Bid[];
  getActiveBids: () => { artwork: Artwork; bid: Bid | null }[];
}

const BiddingContext = createContext<BiddingContextType | undefined>(undefined);

export function BiddingProvider({ children }: { children: React.ReactNode }) {
  const [artworks, setArtworks] = useState<Artwork[]>(mockArtworks);
  const [bids, setBids] = useState<Bid[]>(mockBids);
  const { toast } = useToast();

  // Place a bid on an artwork
  const placeBid = async (artworkId: string, amount: number) => {
    try {
      // Find the artwork
      const artworkIndex = artworks.findIndex(artwork => artwork.id === artworkId);
      
      if (artworkIndex === -1) {
        throw new Error('Artwork not found');
      }
      
      const artwork = artworks[artworkIndex];
      
      // Check if the bid is higher than the current bid
      if (amount <= artwork.bidding.currentBid) {
        throw new Error('Bid must be higher than the current bid');
      }
      
      // Check if the auction has ended
      if (new Date() > artwork.bidding.endsAt) {
        throw new Error('Auction has ended');
      }
      
      // Create a new bid
      const newBid: Bid = {
        id: `bid-${Date.now()}`,
        artworkId,
        artwork: {
          title: artwork.title,
          imageUrl: artwork.imageUrl,
        },
        amount,
        bidder: {
          id: 'user1', // In a real app, this would be the current user's ID
          name: 'Jamie Smith', // In a real app, this would be the current user's name
          avatar: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=150',
        },
        timestamp: new Date(),
      };
      
      // Update the artwork's current bid
      const updatedArtwork = {
        ...artwork,
        bidding: {
          ...artwork.bidding,
          currentBid: amount,
          currentBidder: 'Jamie Smith', // In a real app, this would be the current user's name
        },
      };
      
      // Update state
      const updatedArtworks = [...artworks];
      updatedArtworks[artworkIndex] = updatedArtwork;
      
      setArtworks(updatedArtworks);
      setBids([newBid, ...bids]);
      
      // Show success toast
      toast({
        title: 'Bid Placed Successfully',
        description: `You bid $${amount} on ${artwork.title}`,
        variant: 'default',
      });
      
    } catch (error) {
      console.error('Failed to place bid:', error);
      
      // Show error toast
      toast({
        title: 'Failed to Place Bid',
        description: error instanceof Error ? error.message : 'An unexpected error occurred',
        variant: 'destructive',
      });
      
      throw error;
    }
  };

  // Get artwork by ID
  const getArtworkById = (id: string) => {
    return artworks.find(artwork => artwork.id === id);
  };

  // Get all bids placed by the current user
  const getUserBids = () => {
    // In a real app, this would filter by the current user's ID
    return bids.filter(bid => bid.bidder.id === 'user1');
  };

  // Get all active auctions with the current user's bids
  const getActiveBids = () => {
    return artworks
      .filter(artwork => new Date() < artwork.bidding.endsAt)
      .map(artwork => {
        const userBid = bids.find(
          bid => bid.artworkId === artwork.id && bid.bidder.id === 'user1'
        );
        
        return {
          artwork,
          bid: userBid || null,
        };
      });
  };

  const value = {
    artworks,
    bids,
    placeBid,
    getArtworkById,
    getUserBids,
    getActiveBids,
  };

  return <BiddingContext.Provider value={value}>{children}</BiddingContext.Provider>;
}

export const useBidding = (): BiddingContextType => {
  const context = useContext(BiddingContext);
  if (context === undefined) {
    throw new Error('useBidding must be used within a BiddingProvider');
  }
  return context;
};