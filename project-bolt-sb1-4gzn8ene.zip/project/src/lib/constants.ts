// Types for the application
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'artist' | 'designer';
  avatar: string;
  bio: string;
  followers: number;
  following: number;
  uploads: number;
  joinedAt: Date;
}

export interface Artwork {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  artist: {
    id: string;
    name: string;
    avatar: string;
  };
  tags: string[];
  category: string;
  likes: number;
  comments: number;
  createdAt: Date;
  bidding: {
    startingPrice: number;
    currentBid: number;
    currentBidder: string | null;
    endsAt: Date;
  };
}

export interface Bid {
  id: string;
  artworkId: string;
  artwork: {
    title: string;
    imageUrl: string;
  };
  amount: number;
  bidder: {
    id: string;
    name: string;
    avatar: string;
  };
  timestamp: Date;
}

// Initial categories and tags for filtering
export const categories = [
  'Digital Art',
  'Photography',
  'Illustration',
  'UI/UX Design',
  '3D Modeling',
  'Animation',
  'Painting',
  'Sculpture',
  'Graphic Design',
  'Mixed Media',
];

export const tags = [
  'Abstract',
  'Portrait',
  'Landscape',
  'Minimalist',
  'Futuristic',
  'Vintage',
  'Nature',
  'Urban',
  'Surreal',
  'Typography',
  'Geometric',
  'Conceptual',
  'Character Design',
  'Product Design',
  'Environmental',
];

// Navigation items
export const navItems = [
  {
    title: 'Home',
    href: '/',
  },
  {
    title: 'Gallery',
    href: '/gallery',
  },
  {
    title: 'Discover',
    href: '/discover',
  },
  {
    title: 'About',
    href: '/about',
  },
];

// Mock social links for footer
export const socialLinks = [
  {
    name: 'Twitter',
    url: 'https://twitter.com',
    icon: 'Twitter',
  },
  {
    name: 'Instagram',
    url: 'https://instagram.com',
    icon: 'Instagram',
  },
  {
    name: 'Facebook',
    url: 'https://facebook.com',
    icon: 'Facebook',
  },
  {
    name: 'YouTube',
    url: 'https://youtube.com',
    icon: 'Youtube',
  },
];

// Mock data for testimonials
export const testimonials = [
  {
    quote: "Creative Hub has transformed how I collaborate with clients. The bidding system makes pricing my work fair and transparent.",
    author: "Alex Morgan",
    role: "Digital Illustrator",
    avatar: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150"
  },
  {
    quote: "I've found incredible artists to collaborate with on my game development projects through the platform.",
    author: "Sarah Chen",
    role: "Game Developer",
    avatar: "https://images.pexels.com/photos/2613260/pexels-photo-2613260.jpeg?auto=compress&cs=tinysrgb&w=150"
  },
  {
    quote: "As someone just starting out in design, the feedback I've received from the community has been invaluable.",
    author: "Jordan Lee",
    role: "UI Designer",
    avatar: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150"
  },
];

// Featured artists
export const featuredArtists = [
  {
    id: "1",
    name: "Elena Bright",
    role: "Digital Artist",
    avatar: "https://images.pexels.com/photos/2613260/pexels-photo-2613260.jpeg?auto=compress&cs=tinysrgb&w=150",
    bio: "Creating vibrant digital landscapes and character designs",
    followers: 4582
  },
  {
    id: "2",
    name: "Marcus Rivera",
    role: "Photographer",
    avatar: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150",
    bio: "Capturing urban architecture and city life",
    followers: 3245
  },
  {
    id: "3",
    name: "Zoe Taylor",
    role: "Illustrator",
    avatar: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150",
    bio: "Specializing in stylized character design and storybook illustration",
    followers: 5621
  },
];

// Mock artwork data
export const mockArtworks: Artwork[] = [
  {
    id: "1",
    title: "Neon Dreams",
    description: "A futuristic cityscape bathed in neon lights, exploring themes of technology and isolation.",
    imageUrl: "https://images.pexels.com/photos/1910236/pexels-photo-1910236.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    artist: {
      id: "1",
      name: "Elena Bright",
      avatar: "https://images.pexels.com/photos/2613260/pexels-photo-2613260.jpeg?auto=compress&cs=tinysrgb&w=150",
    },
    tags: ["Futuristic", "Digital Art", "Urban"],
    category: "Digital Art",
    likes: 243,
    comments: 42,
    createdAt: new Date(2023, 5, 15),
    bidding: {
      startingPrice: 350,
      currentBid: 620,
      currentBidder: "Marcus Rivera",
      endsAt: new Date(Date.now() + 86400000 * 3), // 3 days from now
    },
  },
  {
    id: "2",
    title: "Tranquil Forest",
    description: "A peaceful forest scene capturing the morning light through the trees.",
    imageUrl: "https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    artist: {
      id: "2",
      name: "Marcus Rivera",
      avatar: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150",
    },
    tags: ["Nature", "Photography", "Landscape"],
    category: "Photography",
    likes: 187,
    comments: 31,
    createdAt: new Date(2023, 6, 22),
    bidding: {
      startingPrice: 200,
      currentBid: 450,
      currentBidder: "Zoe Taylor",
      endsAt: new Date(Date.now() + 86400000 * 5), // 5 days from now
    },
  },
  {
    id: "3",
    title: "Abstract Emotions",
    description: "An exploration of human emotions through abstract shapes and vibrant colors.",
    imageUrl: "https://images.pexels.com/photos/3699270/pexels-photo-3699270.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    artist: {
      id: "3",
      name: "Zoe Taylor",
      avatar: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150",
    },
    tags: ["Abstract", "Digital Art", "Conceptual"],
    category: "Digital Art",
    likes: 321,
    comments: 57,
    createdAt: new Date(2023, 7, 8),
    bidding: {
      startingPrice: 400,
      currentBid: 400,
      currentBidder: null,
      endsAt: new Date(Date.now() + 86400000 * 7), // 7 days from now
    },
  },
  {
    id: "4",
    title: "Urban Solitude",
    description: "A study of solitude in urban environments through architectural photography.",
    imageUrl: "https://images.pexels.com/photos/3052361/pexels-photo-3052361.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    artist: {
      id: "2",
      name: "Marcus Rivera",
      avatar: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150",
    },
    tags: ["Urban", "Photography", "Architecture"],
    category: "Photography",
    likes: 156,
    comments: 23,
    createdAt: new Date(2023, 8, 14),
    bidding: {
      startingPrice: 250,
      currentBid: 380,
      currentBidder: "Elena Bright",
      endsAt: new Date(Date.now() + 86400000 * 2), // 2 days from now
    },
  },
  {
    id: "5",
    title: "Character Concept - Elara",
    description: "Character design concept for a fantasy game protagonist.",
    imageUrl: "https://images.pexels.com/photos/1074535/pexels-photo-1074535.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    artist: {
      id: "1",
      name: "Elena Bright",
      avatar: "https://images.pexels.com/photos/2613260/pexels-photo-2613260.jpeg?auto=compress&cs=tinysrgb&w=150",
    },
    tags: ["Character Design", "Digital Art", "Fantasy"],
    category: "Illustration",
    likes: 289,
    comments: 47,
    createdAt: new Date(2023, 9, 5),
    bidding: {
      startingPrice: 500,
      currentBid: 750,
      currentBidder: "Jordan Lee",
      endsAt: new Date(Date.now() + 86400000 * 4), // 4 days from now
    },
  },
  {
    id: "6",
    title: "Minimalist Brand Identity",
    description: "A clean, minimalist brand identity for a modern tech startup.",
    imageUrl: "https://images.pexels.com/photos/3183153/pexels-photo-3183153.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    artist: {
      id: "3",
      name: "Zoe Taylor",
      avatar: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150",
    },
    tags: ["Minimalist", "Graphic Design", "Typography"],
    category: "Graphic Design",
    likes: 210,
    comments: 38,
    createdAt: new Date(2023, 10, 17),
    bidding: {
      startingPrice: 300,
      currentBid: 300,
      currentBidder: null,
      endsAt: new Date(Date.now() + 86400000 * 6), // 6 days from now
    },
  },
];

// Mock user data
export const mockUser: User = {
  id: "user1",
  name: "Jamie Smith",
  email: "jamie@example.com",
  role: "artist",
  avatar: "https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=150",
  bio: "Digital artist specializing in concept art and character design for games and animation.",
  followers: 1243,
  following: 356,
  uploads: 24,
  joinedAt: new Date(2022, 3, 15),
};

// Mock bids for user
export const mockBids: Bid[] = [
  {
    id: "bid1",
    artworkId: "1",
    artwork: {
      title: "Neon Dreams",
      imageUrl: "https://images.pexels.com/photos/1910236/pexels-photo-1910236.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    amount: 620,
    bidder: {
      id: "user2",
      name: "Marcus Rivera",
      avatar: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150",
    },
    timestamp: new Date(2023, 11, 18),
  },
  {
    id: "bid2",
    artworkId: "2",
    artwork: {
      title: "Tranquil Forest",
      imageUrl: "https://images.pexels.com/photos/1287145/pexels-photo-1287145.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    },
    amount: 450,
    bidder: {
      id: "user3",
      name: "Zoe Taylor",
      avatar: "https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=150",
    },
    timestamp: new Date(2023, 11, 20),
  },
];

// Mock recommendations for users
export const mockRecommendations = [
  {
    id: "rec1",
    type: "artwork",
    title: "Abstract Waves",
    imageUrl: "https://images.pexels.com/photos/3699270/pexels-photo-3699270.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    artist: "Maya Johnson",
    reason: "Based on your interest in abstract art",
  },
  {
    id: "rec2",
    type: "artist",
    name: "Daniel Park",
    avatar: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150",
    specialty: "3D Character Design",
    reason: "Similar style to artists you follow",
  },
  {
    id: "rec3",
    type: "artwork",
    title: "Cyberpunk Street",
    imageUrl: "https://images.pexels.com/photos/1910236/pexels-photo-1910236.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    artist: "Leo Chen",
    reason: "Based on your recent bids",
  },
];