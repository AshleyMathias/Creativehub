import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { formatCurrency, formatRelativeTime } from '@/lib/utils';
import { Artwork, Bid } from '@/lib/constants';

interface BidCardProps {
  artwork: Artwork;
  bid?: Bid | null;
  isUserBid?: boolean;
}

export function BidCard({ artwork, bid, isUserBid = false }: BidCardProps) {
  const hasCurrentBid = artwork.bidding.currentBidder !== null;

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-md">
      <div className="relative">
        <img
          src={artwork.imageUrl}
          alt={artwork.title}
          className="w-full aspect-[3/2] object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
          <div className="text-white">
            <Link to={`/artwork/${artwork.id}`}>
              <h3 className="font-semibold text-lg hover:underline">{artwork.title}</h3>
            </Link>
            <div className="flex items-center space-x-2 text-sm">
              <Avatar className="h-5 w-5">
                <AvatarImage src={artwork.artist.avatar} />
                <AvatarFallback>{artwork.artist.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <span>{artwork.artist.name}</span>
            </div>
          </div>
        </div>
      </div>
      <CardContent className="p-4 space-y-3">
        <div className="flex justify-between items-center">
          <div>
            <span className="text-sm text-muted-foreground">Current Bid</span>
            <p className="font-semibold text-lg">
              {hasCurrentBid
                ? formatCurrency(artwork.bidding.currentBid)
                : formatCurrency(artwork.bidding.startingPrice)}
            </p>
          </div>
          
          {isUserBid && bid && (
            <div className="text-right">
              <span className="text-sm text-muted-foreground">Your Bid</span>
              <p className="font-medium text-success">
                {formatCurrency(bid.amount)}
              </p>
            </div>
          )}
          
          {hasCurrentBid && !isUserBid && (
            <div className="text-right">
              <span className="text-sm text-muted-foreground">Top Bidder</span>
              <p className="font-medium">
                {artwork.bidding.currentBidder}
              </p>
            </div>
          )}
        </div>
        
        <div className="flex justify-between items-center text-sm">
          <span className="text-muted-foreground">
            Ends in {formatRelativeTime(artwork.bidding.endsAt)}
          </span>
          
          {bid && (
            <span className={`font-medium ${
              artwork.bidding.currentBidder === 'Jamie Smith'
                ? 'text-success'
                : 'text-muted-foreground'
            }`}>
              {artwork.bidding.currentBidder === 'Jamie Smith'
                ? 'Winning'
                : 'Outbid'}
            </span>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Link to={`/artwork/${artwork.id}`} className="w-full">
          <Button variant="outline" className="w-full">
            View Auction
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}