import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Link } from 'react-router-dom';

interface UserCardProps {
  id: string;
  name: string;
  role: string;
  avatar: string;
  bio: string;
  followers: number;
  showFollowButton?: boolean;
}

export function UserCard({
  id,
  name,
  role,
  avatar,
  bio,
  followers,
  showFollowButton = true,
}: UserCardProps) {
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-md">
      <CardHeader className="p-0">
        <div className="h-20 bg-gradient-to-r from-primary/50 to-accent/50"></div>
      </CardHeader>
      <CardContent className="pt-0 p-6">
        <div className="flex flex-col items-center -mt-10">
          <Avatar className="h-16 w-16 border-4 border-background">
            <AvatarImage src={avatar} alt={name} />
            <AvatarFallback>{name.charAt(0)}</AvatarFallback>
          </Avatar>
          <Link to={`/profile/${id}`}>
            <h3 className="mt-3 font-semibold text-lg hover:text-primary transition-colors">
              {name}
            </h3>
          </Link>
          <p className="text-sm text-muted-foreground">{role}</p>
          <p className="text-sm text-center mt-3 line-clamp-2">{bio}</p>
          <p className="text-sm text-muted-foreground mt-2">
            {followers.toLocaleString()} followers
          </p>
        </div>
      </CardContent>
      {showFollowButton && (
        <CardFooter className="px-6 pb-6 pt-0 flex justify-center">
          <Button variant="outline" className="w-full">
            Follow
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}