import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { formatCurrency, formatRelativeTime, formatTimeRemaining } from '@/lib/utils';
import { Heart, MessageCircle, MoreVertical, Timer } from 'lucide-react';
import { Artwork } from '@/lib/constants';
import { useBidding } from '@/context/BiddingContext';
import { useAuth } from '@/context/AuthContext';

interface ArtworkCardProps {
  artwork: Artwork;
  onBid?: (id: string, amount: number) => void;
}

export function ArtworkCard({ artwork }: ArtworkCardProps) {
  const { isAuthenticated } = useAuth();
  const { placeBid } = useBidding();
  const [bidAmount, setBidAmount] = useState<number>((artwork.bidding.currentBid || artwork.bidding.startingPrice) + 50);
  const [isLiked, setIsLiked] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handlePlaceBid = async () => {
    try {
      await placeBid(artwork.id, bidAmount);
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Failed to place bid:', error);
    }
  };

  const hasCurrentBid = artwork.bidding.currentBidder !== null;
  const timeRemaining = formatTimeRemaining(artwork.bidding.endsAt);

  return (
    <div className="artwork-card group bg-card">
      <img
        src={artwork.imageUrl}
        alt={artwork.title}
        className="w-full aspect-[4/3] object-cover rounded-t-xl"
      />
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between">
          <Link to={`/artwork/${artwork.id}`}>
            <h3 className="font-semibold hover:text-primary transition-colors">{artwork.title}</h3>
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreVertical className="h-4 w-4" />
                <span className="sr-only">More options</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Share artwork</DropdownMenuItem>
              <DropdownMenuItem>Save to collection</DropdownMenuItem>
              <DropdownMenuItem>Report artwork</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center space-x-2 text-sm">
          <Link to={`/profile/${artwork.artist.id}`} className="flex items-center space-x-1">
            <Avatar className="h-5 w-5">
              <AvatarImage src={artwork.artist.avatar} />
              <AvatarFallback>{artwork.artist.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <span className="text-muted-foreground hover:text-foreground transition-colors">
              {artwork.artist.name}
            </span>
          </Link>
          <span className="text-xs text-muted-foreground">
            {formatRelativeTime(artwork.createdAt)}
          </span>
        </div>

        <div className="flex flex-wrap gap-1">
          {artwork.tags.slice(0, 3).map((tag) => (
            <Badge key={tag} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>

        <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setIsLiked(!isLiked)}
            >
              <Heart
                className={`h-4 w-4 ${isLiked ? 'fill-destructive text-destructive' : ''}`}
              />
              <span className="sr-only">Like</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              asChild
            >
              <Link to={`/artwork/${artwork.id}`}>
                <MessageCircle className="h-4 w-4" />
                <span className="sr-only">Comment</span>
              </Link>
            </Button>
          </div>

          <div className="flex flex-col items-end">
            <div className="flex items-center space-x-1 text-xs">
              <Timer className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">{timeRemaining}</span>
            </div>
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="mt-1">
                  {hasCurrentBid
                    ? `Bid (${formatCurrency(artwork.bidding.currentBid)})`
                    : `Bid (${formatCurrency(artwork.bidding.startingPrice)})`}
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Place a Bid</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="flex items-center space-x-4">
                    <div className="relative w-20 h-20 rounded-md overflow-hidden">
                      <img
                        src={artwork.imageUrl}
                        alt={artwork.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-semibold">{artwork.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        by {artwork.artist.name}
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Current Bid:</span>
                      <span className="font-semibold">
                        {hasCurrentBid
                          ? formatCurrency(artwork.bidding.currentBid)
                          : formatCurrency(artwork.bidding.startingPrice)}
                      </span>
                    </div>
                    {hasCurrentBid && (
                      <div className="flex justify-between">
                        <span className="text-sm">Current Bidder:</span>
                        <span>{artwork.bidding.currentBidder}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-sm">Time Remaining:</span>
                      <span>{timeRemaining}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="bidAmount" className="text-sm font-medium">
                      Your Bid Amount:
                    </label>
                    <Input
                      id="bidAmount"
                      type="number"
                      value={bidAmount}
                      onChange={(e) => setBidAmount(Number(e.target.value))}
                      min={
                        hasCurrentBid
                          ? artwork.bidding.currentBid + 10
                          : artwork.bidding.startingPrice
                      }
                      step="10"
                    />
                    <p className="text-xs text-muted-foreground">
                      Bid must be at least{' '}
                      {formatCurrency(
                        hasCurrentBid
                          ? artwork.bidding.currentBid + 10
                          : artwork.bidding.startingPrice
                      )}
                    </p>
                  </div>

                  <div className="flex justify-end space-x-2 pt-2">
                    <Button
                      variant="outline"
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handlePlaceBid}
                      disabled={
                        !isAuthenticated ||
                        bidAmount <
                          (hasCurrentBid
                            ? artwork.bidding.currentBid + 10
                            : artwork.bidding.startingPrice)
                      }
                    >
                      Place Bid
                    </Button>
                  </div>
                  
                  {!isAuthenticated && (
                    <p className="text-xs text-center text-muted-foreground mt-2">
                      You need to{' '}
                      <Link to="/login" className="text-primary underline">
                        log in
                      </Link>{' '}
                      to place a bid.
                    </p>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </div>
  );
}