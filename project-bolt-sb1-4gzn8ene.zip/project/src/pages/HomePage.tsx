import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { ArtworkCard } from '@/components/ArtworkCard';
import { UserCard } from '@/components/UserCard';
import { featuredArtists, mockArtworks, testimonials } from '@/lib/constants';
import { ArrowRight, Palette, Search, Zap } from 'lucide-react';

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center justify-center hero-gradient overflow-hidden">
        <div className="absolute inset-0 bg-background/50 dark:bg-background/80"></div>
        <div className="container px-4 md:px-6 relative z-10 text-center space-y-8">
          <div className="space-y-4 max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter animate-fade-in">
              Where Creativity Meets Opportunity
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto animate-slide-up">
              Upload, discover, bid, and collaborate on creative content in a thriving digital community.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 animate-slide-up">
            <Link to="/register">
              <Button size="lg" className="px-8">Join the Hub</Button>
            </Link>
            <Link to="/gallery">
              <Button size="lg" variant="outline" className="px-8">
                Explore Creatives
              </Button>
            </Link>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-background to-transparent"></div>
      </section>

      {/* Features Section */}
      <section className="section">
        <div className="container px-4 md:px-6">
          <h2 className="section-title text-3xl md:text-4xl">Unleash Your Creative Potential</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            <div className="flex flex-col items-center text-center space-y-4 p-6 bg-card rounded-xl shadow-sm">
              <div className="p-3 rounded-full bg-primary/10 text-primary">
                <Palette className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold">Upload</h3>
              <p className="text-muted-foreground">
                Showcase your artwork to a global audience of artists, collectors, and enthusiasts.
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4 p-6 bg-card rounded-xl shadow-sm">
              <div className="p-3 rounded-full bg-secondary/10 text-secondary">
                <Search className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold">Discover</h3>
              <p className="text-muted-foreground">
                Explore stunning artwork from talented creators around the world.
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4 p-6 bg-card rounded-xl shadow-sm">
              <div className="p-3 rounded-full bg-accent/10 text-accent">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-8 w-8"
                >
                  <circle cx="12" cy="12" r="10" />
                  <path d="M16 12h-6.5" />
                  <path d="M16 7h-7.5" />
                  <path d="M16 17h-7.5" />
                  <circle cx="7.5" cy="7" r="1" />
                  <circle cx="7.5" cy="12" r="1" />
                  <circle cx="7.5" cy="17" r="1" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold">Bid</h3>
              <p className="text-muted-foreground">
                Participate in auctions for unique artwork directly from creators.
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4 p-6 bg-card rounded-xl shadow-sm">
              <div className="p-3 rounded-full bg-success/10 text-success">
                <Zap className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold">Collaborate</h3>
              <p className="text-muted-foreground">
                Connect with fellow creatives to bring ambitious projects to life.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Artworks */}
      <section className="section bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl md:text-4xl font-bold">Featured Artworks</h2>
            <Link to="/gallery" className="flex items-center text-primary">
              View all <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockArtworks.slice(0, 3).map((artwork) => (
              <ArtworkCard key={artwork.id} artwork={artwork} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Artists */}
      <section className="section">
        <div className="container px-4 md:px-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl md:text-4xl font-bold">Featured Artists</h2>
            <Link to="/discover" className="flex items-center text-primary">
              View all <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredArtists.map((artist) => (
              <UserCard
                key={artist.id}
                id={artist.id}
                name={artist.name}
                role={artist.role}
                avatar={artist.avatar}
                bio={artist.bio}
                followers={artist.followers}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section bg-muted/30">
        <div className="container px-4 md:px-6">
          <h2 className="section-title text-3xl md:text-4xl">What Our Community Says</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-card rounded-xl p-6 shadow-sm"
              >
                <p className="italic text-muted-foreground">&ldquo;{testimonial.quote}&rdquo;</p>
                <div className="flex items-center space-x-4 mt-6">
                  <Avatar>
                    <AvatarImage src={testimonial.avatar} alt={testimonial.author} />
                    <AvatarFallback>{testimonial.author.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{testimonial.author}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Join Our Creative Community?</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">
            Start sharing your work, discovering new artists, and bidding on unique creations today.
          </p>
          <Link to="/register">
            <Button size="lg" variant="secondary" className="px-8">
              Join Creative Hub
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}