import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { UserCard } from '@/components/UserCard';
import { featuredArtists } from '@/lib/constants';
import { Search } from 'lucide-react';

export default function DiscoverPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredArtists, setFilteredArtists] = useState(featuredArtists);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    const filtered = featuredArtists.filter(
      (artist) =>
        artist.name.toLowerCase().includes(query.toLowerCase()) ||
        artist.role.toLowerCase().includes(query.toLowerCase()) ||
        artist.bio.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredArtists(filtered);
  };

  return (
    <div className="container px-4 md:px-6 py-10">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Discover Creators</h1>
            <p className="text-muted-foreground mt-2">
              Find and follow talented artists and designers from around the world
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Link to="/gallery">
              <Button variant="outline">View Gallery</Button>
            </Link>
            <Link to="/upload">
              <Button>Share Your Work</Button>
            </Link>
          </div>
        </div>

        {/* Search */}
        <div className="relative max-w-md mx-auto mb-12">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, role, or keywords..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
          />
        </div>

        {/* Artists Grid */}
        {filteredArtists.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredArtists.map((artist) => (
              <UserCard
                key={artist.id}
                id={artist.id}
                name={artist.name}
                role={artist.role}
                avatar={artist.avatar}
                bio={artist.bio}
                followers={artist.followers}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="text-muted-foreground text-4xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold mb-2">No creators found</h3>
            <p className="text-muted-foreground mb-6">
              Try adjusting your search terms or explore our featured artists
            </p>
            <Button onClick={() => handleSearch('')}>Show All Creators</Button>
          </div>
        )}
      </div>
    </div>
  );
}