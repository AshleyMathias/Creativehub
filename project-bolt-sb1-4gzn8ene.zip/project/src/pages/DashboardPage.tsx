import { Link } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/context/AuthContext';
import { useBidding } from '@/context/BiddingContext';
import { ArtworkCard } from '@/components/ArtworkCard';
import { BidCard } from '@/components/BidCard';
import { mockArtworks } from '@/lib/constants';
import { FileUp, Heart, Mail, MessageSquare, Upload, Users } from 'lucide-react';

export default function DashboardPage() {
  const { user } = useAuth();
  const { getActiveBids } = useBidding();
  
  const activeBids = getActiveBids();
  
  // Filter artworks to those uploaded by the current user (for demo purposes)
  const userArtworks = mockArtworks.slice(0, 2);

  return (
    <div className="container px-4 md:px-6 py-10">
      <div className="flex flex-col">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={user?.avatar} alt={user?.name} />
              <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold">{user?.name}'s Dashboard</h1>
              <p className="text-muted-foreground">
                {user?.role.charAt(0).toUpperCase() + user?.role.slice(1)} • Joined{' '}
                {user?.joinedAt.toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="flex space-x-2">
            <Link to="/upload">
              <Button className="flex items-center">
                <Upload className="mr-2 h-4 w-4" />
                Upload Artwork
              </Button>
            </Link>
            <Link to="/profile">
              <Button variant="outline">Edit Profile</Button>
            </Link>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center">
              <div className="p-2 rounded-full bg-primary/10 text-primary mb-2">
                <FileUp className="h-5 w-5" />
              </div>
              <div className="text-2xl font-bold">{user?.uploads}</div>
              <p className="text-sm text-muted-foreground">Uploads</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center">
              <div className="p-2 rounded-full bg-secondary/10 text-secondary mb-2">
                <Users className="h-5 w-5" />
              </div>
              <div className="text-2xl font-bold">{user?.followers}</div>
              <p className="text-sm text-muted-foreground">Followers</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center">
              <div className="p-2 rounded-full bg-accent/10 text-accent mb-2">
                <Heart className="h-5 w-5" />
              </div>
              <div className="text-2xl font-bold">{user?.following}</div>
              <p className="text-sm text-muted-foreground">Following</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center">
              <div className="p-2 rounded-full bg-success/10 text-success mb-2">
                <MessageSquare className="h-5 w-5" />
              </div>
              <div className="text-2xl font-bold">24</div>
              <p className="text-sm text-muted-foreground">Comments</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs for different sections */}
        <Tabs defaultValue="my-gallery" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="my-gallery">My Gallery</TabsTrigger>
            <TabsTrigger value="active-bids">Active Bids</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
          </TabsList>
          
          <TabsContent value="my-gallery" className="space-y-4">
            {userArtworks.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {userArtworks.map((artwork) => (
                  <ArtworkCard key={artwork.id} artwork={artwork} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 flex flex-col items-center text-center">
                  <div className="p-4 rounded-full bg-muted mb-4">
                    <FileUp className="h-10 w-10 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">No Uploads Yet</h3>
                  <p className="text-muted-foreground mb-6 max-w-md">
                    You haven't uploaded any artwork yet. Start sharing your creativity with the
                    community.
                  </p>
                  <Link to="/upload">
                    <Button>Upload Your First Artwork</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="active-bids" className="space-y-4">
            {activeBids.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeBids.slice(0, 3).map(({ artwork, bid }) => (
                  <BidCard
                    key={artwork.id}
                    artwork={artwork}
                    bid={bid}
                    isUserBid={!!bid}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 flex flex-col items-center text-center">
                  <div className="p-4 rounded-full bg-muted mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-10 w-10 text-muted-foreground"
                    >
                      <circle cx="12" cy="12" r="10" />
                      <path d="M16 12h-6.5" />
                      <path d="M16 7h-7.5" />
                      <path d="M16 17h-7.5" />
                      <circle cx="7.5" cy="7" r="1" />
                      <circle cx="7.5" cy="12" r="1" />
                      <circle cx="7.5" cy="17" r="1" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">No Active Bids</h3>
                  <p className="text-muted-foreground mb-6 max-w-md">
                    You're not currently bidding on any artwork. Explore the gallery to find pieces
                    you love.
                  </p>
                  <Link to="/gallery">
                    <Button>Explore Gallery</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="messages" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Messages</CardTitle>
              </CardHeader>
              <CardContent className="py-8 flex flex-col items-center text-center">
                <div className="p-4 rounded-full bg-muted mb-4">
                  <Mail className="h-10 w-10 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Your Inbox is Empty</h3>
                <p className="text-muted-foreground max-w-md">
                  No new messages. Connect with other artists by commenting on their work or starting
                  a collaboration.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}