import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { testimonials } from '@/lib/constants';
import { BrainCircuit, Palette, Search, Users } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="p-3 rounded-full bg-primary/10 text-primary">
              <BrainCircuit className="h-12 w-12" />
            </div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold">About Creative Hub</h1>
            <p className="text-xl text-muted-foreground max-w-3xl">
              We're building a vibrant community where creativity thrives and artists can showcase,
              sell, and collaborate on exceptional work.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-3 rounded-full bg-primary/10 text-primary">
                <Palette className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold">Empower Creativity</h3>
              <p className="text-muted-foreground">
                We provide artists and designers with the tools they need to showcase their work and
                reach a global audience.
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-3 rounded-full bg-secondary/10 text-secondary">
                <Users className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold">Foster Community</h3>
              <p className="text-muted-foreground">
                Build meaningful connections between creators, collectors, and art enthusiasts from
                around the world.
              </p>
            </div>
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-3 rounded-full bg-accent/10 text-accent">
                <Search className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold">Discover Talent</h3>
              <p className="text-muted-foreground">
                Make it easy to discover and support emerging artists while connecting with established
                creators.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-muted/30">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold">What Our Community Says</h2>
            <p className="text-muted-foreground mt-2">
              Hear from the artists and designers who make Creative Hub special
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-card rounded-xl p-6 shadow-sm">
                <p className="italic text-muted-foreground">
                  &ldquo;{testimonial.quote}&rdquo;
                </p>
                <div className="flex items-center space-x-4 mt-6">
                  <Avatar>
                    <AvatarImage src={testimonial.avatar} alt={testimonial.author} />
                    <AvatarFallback>{testimonial.author.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{testimonial.author}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Creative Community</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Start your creative journey today and connect with artists and designers from around the
            world.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/register">
              <Button size="lg" variant="secondary">
                Join Creative Hub
              </Button>
            </Link>
            <Link to="/gallery">
              <Button size="lg" variant="outline" className="bg-primary-foreground/10">
                Explore Gallery
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}