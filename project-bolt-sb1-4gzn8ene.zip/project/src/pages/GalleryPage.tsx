import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArtworkCard } from '@/components/ArtworkCard';
import { categories, mockArtworks, tags } from '@/lib/constants';
import { FilterX, Search } from 'lucide-react';

export default function GalleryPage() {
  const [filteredArtworks, setFilteredArtworks] = useState(mockArtworks);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [currentLayout, setCurrentLayout] = useState<'grid' | 'masonry'>('grid');

  // Apply filters when dependencies change
  useEffect(() => {
    let results = mockArtworks;
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      results = results.filter(
        (artwork) =>
          artwork.title.toLowerCase().includes(query) ||
          artwork.description.toLowerCase().includes(query) ||
          artwork.artist.name.toLowerCase().includes(query)
      );
    }
    
    // Apply category filter
    if (selectedCategory) {
      results = results.filter((artwork) => artwork.category === selectedCategory);
    }
    
    // Apply tag filters
    if (selectedTags.length > 0) {
      results = results.filter((artwork) =>
        selectedTags.some((tag) => artwork.tags.includes(tag))
      );
    }
    
    setFilteredArtworks(results);
  }, [searchQuery, selectedCategory, selectedTags]);

  const handleTagSelect = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory(null);
    setSelectedTags([]);
  };

  return (
    <div className="container px-4 md:px-6 py-10">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Artwork Gallery</h1>
          <p className="text-muted-foreground mt-2">
            Discover and bid on exceptional artwork from creative professionals
          </p>
        </div>

        {/* Search and Filters */}
        <div className="space-y-6 mb-10">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by title, description, or artist..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="text-sm font-medium">Categories:</div>
            <Button
              variant={selectedCategory === null ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(null)}
            >
              All
            </Button>
            {categories.slice(0, 6).map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="text-sm font-medium">Tags:</div>
            {tags.slice(0, 10).map((tag) => (
              <div
                key={tag}
                className={`px-3 py-1 rounded-full text-sm cursor-pointer transition-colors ${
                  selectedTags.includes(tag)
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary/50 text-secondary-foreground hover:bg-secondary'
                }`}
                onClick={() => handleTagSelect(tag)}
              >
                {tag}
              </div>
            ))}
          </div>

          {(searchQuery || selectedCategory || selectedTags.length > 0) && (
            <div className="flex justify-between items-center">
              <div className="text-sm text-muted-foreground">
                Showing {filteredArtworks.length} results
              </div>
              <Button variant="ghost" size="sm" onClick={clearFilters} className="flex items-center">
                <FilterX className="h-4 w-4 mr-2" />
                Clear Filters
              </Button>
            </div>
          )}
        </div>

        {/* Layout Tabs */}
        <Tabs defaultValue="grid" onValueChange={(value) => setCurrentLayout(value as 'grid' | 'masonry')}>
          <div className="flex justify-end mb-6">
            <TabsList>
              <TabsTrigger value="grid">Grid</TabsTrigger>
              <TabsTrigger value="masonry">Masonry</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="grid" className="space-y-4">
            {filteredArtworks.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredArtworks.map((artwork) => (
                  <ArtworkCard key={artwork.id} artwork={artwork} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="text-muted-foreground text-4xl mb-4">🔍</div>
                <h3 className="text-xl font-semibold mb-2">No matching artworks found</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  Try adjusting your search or filters to find what you're looking for.
                </p>
                <Button onClick={clearFilters}>Clear All Filters</Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="masonry" className="space-y-4">
            {filteredArtworks.length > 0 ? (
              <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
                {filteredArtworks.map((artwork) => (
                  <div key={artwork.id} className="break-inside-avoid">
                    <ArtworkCard artwork={artwork} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="text-muted-foreground text-4xl mb-4">🔍</div>
                <h3 className="text-xl font-semibold mb-2">No matching artworks found</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  Try adjusting your search or filters to find what you're looking for.
                </p>
                <Button onClick={clearFilters}>Clear All Filters</Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}