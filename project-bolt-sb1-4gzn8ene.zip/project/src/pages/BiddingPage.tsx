import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BidCard } from '@/components/BidCard';
import { useBidding } from '@/context/BiddingContext';
import { Button } from '@/components/ui/button';
import { ArrowRight, Award, History } from 'lucide-react';

export default function BiddingPage() {
  const { artworks, getUserBids } = useBidding();
  const [activeBids, setActiveBids] = useState<any[]>([]);
  const [userBids, setUserBids] = useState<any[]>([]);

  useEffect(() => {
    // Get active auctions
    const active = artworks.filter(artwork => new Date() < artwork.bidding.endsAt);
    setActiveBids(active);

    // Get user's bids
    const bids = getUserBids();
    const artworksWithUserBids = bids.map(bid => {
      const artwork = artworks.find(a => a.id === bid.artworkId);
      return { artwork, bid };
    }).filter(item => item.artwork);
    
    setUserBids(artworksWithUserBids);
  }, [artworks, getUserBids]);

  return (
    <div className="container px-4 md:px-6 py-10">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Bidding Overview</h1>
          <p className="text-muted-foreground mt-2">
            Manage your active bids and discover new artwork for bidding
          </p>
        </div>

        <Tabs defaultValue="active-auctions" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="active-auctions" className="flex items-center">
              <Award className="h-4 w-4 mr-2" />
              Active Auctions
            </TabsTrigger>
            <TabsTrigger value="my-bids" className="flex items-center">
              <History className="h-4 w-4 mr-2" />
              My Bids
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active-auctions" className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Active Auctions</h2>
              <Link to="/gallery" className="flex items-center text-primary text-sm">
                Browse more artwork <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            
            {activeBids.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeBids.map((artwork) => (
                  <BidCard key={artwork.id} artwork={artwork} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-card rounded-lg">
                <div className="text-muted-foreground text-4xl mb-4">🔍</div>
                <h3 className="text-xl font-semibold mb-2">No Active Auctions</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  There are no active auctions at the moment. Check back soon or browse the gallery.
                </p>
                <Link to="/gallery">
                  <Button>Explore Gallery</Button>
                </Link>
              </div>
            )}
          </TabsContent>

          <TabsContent value="my-bids" className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Your Active Bids</h2>
            </div>
            
            {userBids.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {userBids.map(({ artwork, bid }) => (
                  <BidCard
                    key={artwork.id}
                    artwork={artwork}
                    bid={bid}
                    isUserBid={true}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-card rounded-lg">
                <div className="text-muted-foreground text-4xl mb-4">💰</div>
                <h3 className="text-xl font-semibold mb-2">No Active Bids</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  You haven't placed any bids yet. Browse the gallery to find artwork you love and place your first bid.
                </p>
                <Link to="/gallery">
                  <Button>Start Bidding</Button>
                </Link>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}