import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { useBidding } from '@/context/BiddingContext';
import { useAuth } from '@/context/AuthContext';
import { formatCurrency, formatRelativeTime, formatTimeRemaining } from '@/lib/utils';
import { ArtworkCard } from '@/components/ArtworkCard';
import { mockArtworks } from '@/lib/constants';
import { Clock, Heart, MessageCircle, Share2, Timer } from 'lucide-react';

export default function ArtworkDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { getArtworkById, placeBid } = useBidding();
  const { isAuthenticated } = useAuth();
  const [bidAmount, setBidAmount] = useState<number>(0);
  const [isLiked, setIsLiked] = useState(false);
  const [comment, setComment] = useState('');
  
  // Get artwork details
  const artwork = getArtworkById(id || '') || mockArtworks[0];
  
  // Similar artworks
  const similarArtworks = mockArtworks
    .filter((a) => a.id !== artwork.id && a.category === artwork.category)
    .slice(0, 3);
  
  // Set initial bid amount if not set
  if (bidAmount === 0) {
    setBidAmount(
      artwork.bidding.currentBidder
        ? artwork.bidding.currentBid + 10
        : artwork.bidding.startingPrice
    );
  }
  
  const handlePlaceBid = async () => {
    try {
      await placeBid(artwork.id, bidAmount);
    } catch (error) {
      console.error('Failed to place bid:', error);
    }
  };

  const handleComment = () => {
    if (comment.trim()) {
      console.log('Comment submitted:', comment);
      setComment('');
      // In a real app, this would send the comment to a backend
    }
  };
  
  const hasCurrentBid = artwork.bidding.currentBidder !== null;

  return (
    <div className="container px-4 md:px-6 py-10">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Artwork Image and Details */}
          <div className="lg:col-span-3 space-y-6">
            <div className="relative overflow-hidden rounded-xl">
              <img
                src={artwork.imageUrl}
                alt={artwork.title}
                className="w-full object-cover rounded-xl"
              />
              <Button
                variant="secondary"
                size="icon"
                className="absolute top-4 right-4"
                onClick={() => setIsLiked(!isLiked)}
              >
                <Heart
                  className={`h-5 w-5 ${isLiked ? 'fill-destructive text-destructive' : ''}`}
                />
              </Button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h1 className="text-3xl font-bold">{artwork.title}</h1>
                <Button variant="ghost" size="icon">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>

              <div className="flex items-center space-x-4">
                <Link to={`/profile/${artwork.artist.id}`} className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={artwork.artist.avatar} />
                    <AvatarFallback>{artwork.artist.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">{artwork.artist.name}</p>
                    <p className="text-xs text-muted-foreground">Artist</p>
                  </div>
                </Link>
                <div className="text-sm text-muted-foreground">
                  Posted {formatRelativeTime(artwork.createdAt)}
                </div>
              </div>

              <p className="text-muted-foreground">{artwork.description}</p>

              <div className="flex flex-wrap gap-2">
                {artwork.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Heart className="h-4 w-4 mr-1" />
                  <span>{artwork.likes} likes</span>
                </div>
                <div className="flex items-center">
                  <MessageCircle className="h-4 w-4 mr-1" />
                  <span>{artwork.comments} comments</span>
                </div>
              </div>
            </div>

            <Separator />

            {/* Comments */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Comments</h2>
              
              <div className="flex space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=150" />
                  <AvatarFallback>JS</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-2">
                  <Input
                    placeholder="Add a comment..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                  />
                  <div className="flex justify-end">
                    <Button size="sm" onClick={handleComment} disabled={!comment.trim()}>
                      Post
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Sample comments */}
              <div className="space-y-4 pt-4">
                <div className="flex space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="https://images.pexels.com/photos/2613260/pexels-photo-2613260.jpeg?auto=compress&cs=tinysrgb&w=150" />
                    <AvatarFallback>EB</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <p className="font-medium">Elena Bright</p>
                      <p className="text-xs text-muted-foreground">2 days ago</p>
                    </div>
                    <p className="text-sm mt-1">
                      I love the use of color in this piece. The contrasts are stunning!
                    </p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150" />
                    <AvatarFallback>MR</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <p className="font-medium">Marcus Rivera</p>
                      <p className="text-xs text-muted-foreground">1 day ago</p>
                    </div>
                    <p className="text-sm mt-1">
                      What techniques did you use for the texturing? It looks amazing.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bidding and Similar Artworks */}
          <div className="lg:col-span-2 space-y-8">
            {/* Bidding Card */}
            <Card>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">Current Bid</h2>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>{formatTimeRemaining(artwork.bidding.endsAt)}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-baseline justify-between">
                    <div className="text-3xl font-bold">
                      {hasCurrentBid
                        ? formatCurrency(artwork.bidding.currentBid)
                        : formatCurrency(artwork.bidding.startingPrice)}
                    </div>
                    {hasCurrentBid && (
                      <div className="text-sm">
                        by <span className="font-medium">{artwork.bidding.currentBidder}</span>
                      </div>
                    )}
                  </div>
                </div>

                <Separator />
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="bidAmount" className="text-sm font-medium">
                      Your Bid Amount
                    </label>
                    <div className="flex space-x-2">
                      <Input
                        id="bidAmount"
                        type="number"
                        value={bidAmount}
                        onChange={(e) => setBidAmount(Number(e.target.value))}
                        min={
                          hasCurrentBid
                            ? artwork.bidding.currentBid + 10
                            : artwork.bidding.startingPrice
                        }
                        step="10"
                        className="flex-1"
                      />
                      <Button
                        onClick={handlePlaceBid}
                        disabled={
                          !isAuthenticated ||
                          bidAmount <
                            (hasCurrentBid
                              ? artwork.bidding.currentBid + 10
                              : artwork.bidding.startingPrice)
                        }
                      >
                        Place Bid
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Minimum bid:{' '}
                      {formatCurrency(
                        hasCurrentBid
                          ? artwork.bidding.currentBid + 10
                          : artwork.bidding.startingPrice
                      )}
                    </p>
                  </div>
                  
                  {!isAuthenticated && (
                    <p className="text-sm text-center text-muted-foreground">
                      You need to{' '}
                      <Link to="/login" className="text-primary underline">
                        log in
                      </Link>{' '}
                      to place a bid.
                    </p>
                  )}
                </div>

                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Starting Price</span>
                    <span>{formatCurrency(artwork.bidding.startingPrice)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Auction Ends</span>
                    <span>{new Date(artwork.bidding.endsAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Similar Artworks */}
            <div className="space-y-4">
              <h2 className="text-xl font-semibold">Similar Artwork</h2>
              <div className="space-y-4">
                {similarArtworks.map((artwork) => (
                  <ArtworkCard key={artwork.id} artwork={artwork} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}