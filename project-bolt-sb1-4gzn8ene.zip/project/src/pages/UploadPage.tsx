import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { categories, tags } from '@/lib/constants';
import { formatCurrency } from '@/lib/utils';
import { ImageIcon, Loader2, Upload, X } from 'lucide-react';

const uploadSchema = z.object({
  title: z.string().min(3, { message: 'Title must be at least 3 characters' }).max(100),
  description: z.string().min(10, { message: 'Description must be at least 10 characters' }).max(500),
  category: z.string().min(1, { message: 'Please select a category' }),
  tags: z.string().array().min(1, { message: 'Please add at least one tag' }).max(5),
  startingBid: z.number().min(10, { message: 'Starting bid must be at least $10' }),
  image: z.instanceof(File).optional(),
});

type UploadValues = z.infer<typeof uploadSchema>;

export default function UploadPage() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const form = useForm<UploadValues>({
    resolver: zodResolver(uploadSchema),
    defaultValues: {
      title: '',
      description: '',
      category: '',
      tags: [],
      startingBid: 50,
    },
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue('image', file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const removeImage = () => {
    form.setValue('image', undefined);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
  };

  const handleTagSelect = (tag: string) => {
    if (selectedTags.includes(tag)) {
      const updatedTags = selectedTags.filter((t) => t !== tag);
      setSelectedTags(updatedTags);
      form.setValue('tags', updatedTags);
    } else if (selectedTags.length < 5) {
      const updatedTags = [...selectedTags, tag];
      setSelectedTags(updatedTags);
      form.setValue('tags', updatedTags);
    }
  };

  const onSubmit = async (values: UploadValues) => {
    setIsUploading(true);
    
    try {
      // Simulate API request delay
      await new Promise((resolve) => setTimeout(resolve, 2000));
      
      // In a real app, you would upload to a backend here
      console.log('Uploaded artwork:', values);
      
      toast({
        title: 'Artwork Uploaded Successfully',
        description: 'Your artwork has been uploaded and is now available for bidding.',
      });
      
      navigate('/dashboard');
    } catch (error) {
      console.error('Upload failed:', error);
      
      toast({
        title: 'Upload Failed',
        description: 'There was an error uploading your artwork. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="container px-4 md:px-6 py-10">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Upload Your Artwork</h1>
          <p className="text-muted-foreground mt-2">
            Share your creativity with the world and allow others to bid on your work
          </p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            {/* Image Upload Section */}
            <div className="space-y-2">
              <FormLabel>Artwork Image</FormLabel>
              <div
                className={`border-2 border-dashed rounded-lg p-4 text-center ${
                  previewUrl ? 'border-border' : 'border-input hover:border-primary/50'
                }`}
              >
                {previewUrl ? (
                  <div className="relative">
                    <img
                      src={previewUrl}
                      alt="Artwork preview"
                      className="max-h-80 mx-auto rounded-md"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2"
                      onClick={removeImage}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div
                    className="flex flex-col items-center justify-center py-12 cursor-pointer"
                    onClick={() => document.getElementById('image-upload')?.click()}
                  >
                    <ImageIcon className="h-12 w-12 text-muted-foreground mb-4" />
                    <div className="text-xl font-medium mb-1">Upload your artwork</div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Drag and drop or click to browse
                    </p>
                    <Button
                      type="button"
                      className="flex items-center"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Select File
                    </Button>
                  </div>
                )}
                <Input
                  id="image-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageChange}
                />
              </div>
              <FormDescription>
                Upload a high-quality image of your artwork. Max file size: 10MB.
              </FormDescription>
            </div>

            {/* Title and Description */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your artwork title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe your artwork, inspiration, techniques used, etc."
                      className="min-h-[120px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Category and Tags */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="tags"
                render={() => (
                  <FormItem>
                    <FormLabel>Tags (Select up to 5)</FormLabel>
                    <div className="flex flex-wrap gap-2">
                      {tags.slice(0, 12).map((tag) => (
                        <div
                          key={tag}
                          className={`px-3 py-1 rounded-full text-sm cursor-pointer transition-colors ${
                            selectedTags.includes(tag)
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-secondary/50 text-secondary-foreground hover:bg-secondary'
                          }`}
                          onClick={() => handleTagSelect(tag)}
                        >
                          {tag}
                        </div>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Bidding Settings */}
            <FormField
              control={form.control}
              name="startingBid"
              render={({ field: { value, onChange } }) => (
                <FormItem>
                  <FormLabel>Starting Bid</FormLabel>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => onChange(Math.max(10, value - 10))}
                      >
                        -
                      </Button>
                      <span className="text-xl font-semibold">{formatCurrency(value)}</span>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => onChange(value + 10)}
                      >
                        +
                      </Button>
                    </div>
                    <Slider
                      value={[value]}
                      min={10}
                      max={1000}
                      step={10}
                      onValueChange={(vals) => onChange(vals[0])}
                    />
                    <FormDescription>
                      Set the starting bid for your artwork. Bidders must bid at least this amount.
                    </FormDescription>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Submit Button */}
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" type="button" onClick={() => navigate(-1)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isUploading}>
                {isUploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  'Upload Artwork'
                )}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}